<%*
let chapter = tp.file.title;
%>
# <% chapter %>  
tags: #dead_simple_python #<% chapter.toLowerCase().replace(" ", "_") %>

---

## 🧠 01. 核心知识点（技术主线）  

## 🔎 02. 示例代码与讲解  

## 📘 03. 难点/易混点记录（可选）  

## 💬 04. 精选表达（语言积累）  

## 📚 05. 生词与术语（语言学习）  

## 🧠 06. 我的理解与思考（反思模块）  

## 🔗 07. 关联章节与延伸阅读（可选）  
